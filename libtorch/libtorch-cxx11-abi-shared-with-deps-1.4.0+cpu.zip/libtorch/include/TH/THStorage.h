#pragma once
#include <TH/THStorageFunctions.h>

// Compatability header. Use THStorageFunctions.h instead if you need this.
