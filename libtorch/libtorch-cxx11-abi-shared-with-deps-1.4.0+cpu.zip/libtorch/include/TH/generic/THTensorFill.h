#ifndef TH_GENERIC_FILE
#define TH_GENERIC_FILE "TH/generic/THTensorFill.h"
#else

TH_API void THTensor_(fill)(THTensor *r_, scalar_t value);
TH_API void THTensor_(zero)(THTensor *r_);

#endif
