#pragma once

#include "foxi/onnxifi_loader.h"

namespace caffe2 {
namespace onnx {

onnxifi_library* initOnnxifiLibrary();
} // namespace onnx
} // namespace caffe2
