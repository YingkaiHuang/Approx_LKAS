#ifndef CAFFE2_UTILS_PROTO_CONVERT_H_
#define CAFFE2_UTILS_PROTO_CONVERT_H_

#include "caffe2/core/common.h"
#include "caffe2/proto/caffe2_pb.h"
#include "caffe2/proto/torch_pb.h"

namespace caffe2 {
} // namespace caffe2

#endif // CAFFE2_UTILS_PROTO_CONVERT_H_
